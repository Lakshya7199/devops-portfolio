import "../styles/footer.css"

function Footer() {
  return (
    <footer className="footer">
      © 2025 Lakshya | Built with React & AWS
    </footer>
  )
}

export default Footer
