import "../styles/modal.css"

function Modal({ isOpen, onClose, pdfLink }) {
  if (!isOpen) return null

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <button className="close-btn" onClick={onClose}>×</button>

        <h3>Strengthening Amazon OpenSearch Security with IAM Identity Center (SSO)</h3>

        <p>
            Managing access to Amazon OpenSearch Service using shared master credentials is risky and difficult to scale. It limits visibility, weakens security, and makes access control hard to manage as teams grow.<br></br>
            To solve this, I implemented Role-Based Access Control (RBAC) in Amazon OpenSearch Service using AWS IAM Identity Center through native SAML integration.<br></br>
            🚀 What this setup achieves:<br></br>
            Eliminates shared master credentials<br></br>
            Enables centralized identity and access management<br></br>
            Provides fine-grained permissions using group-based access<br></br>
        </p>

        <a
          href={pdfLink}
          target="_blank"
          className="modal-action-btn"
        >
          View Detailed Research →
        </a>
      </div>
    </div>
  )
}

export default Modal
