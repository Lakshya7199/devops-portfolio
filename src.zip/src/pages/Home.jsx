import { useState } from "react"
import InfoCard from "../components/InfoCard"
import Modal from "../components/Modal"

function Home() {
  const [showModal, setShowModal] = useState(false)

  return (
    <section id="home" className="home">
      <h2>Hi, I’m Lakshya 👋</h2>
      <p>
        DevOps & Cloud Engineer specializing in AWS, Kubernetes,
        Terraform, and scalable cloud infrastructure.
      </p>

      <div className="info-grid">
        {/* Research Card */}
        <div onClick={() => setShowModal(true)}>
          <InfoCard
            title="Research & Deep Dives"
            description="Technical research and explorations on DevOps, AWS, OpenSearch, and Kubernetes."
          />
        </div>

        {/* Achievements Card (normal link for now) */}
        <InfoCard
          title="Achievements"
          description="Certifications, recognitions, and professional milestones."
          link="/docs/achievements.pdf"
        />
      </div>

      {/* Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        pdfLink="/docs/AWS OpenSearch Integration with IAM Identity Center.pdf"
      />
    </section>
  )
}

export default Home
